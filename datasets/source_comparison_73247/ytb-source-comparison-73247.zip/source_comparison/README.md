# Đối chiếu GSDMM: dữ liệu thật và giả lập

Hai nhóm được lọc và huấn luyện riêng; không trộn để làm kết luận về người xem thật. Nhóm thật xét metadata video gốc; nhóm giả lập dùng metadata giả lập làm đối chứng. Không xác minh âm thanh hoặc nơi sản xuất tại Việt Nam chỉ bằng metadata.

real/ và synthetic/ có topics/comments/part-00000.parquet và sentiment/comments/part-00000.parquet: các bảng bình luận đều đúng 18 cột Core, không thêm cờ/nhãn và không sửa giá trị giữ lại. Sentiment giữ câu ngắn/emoji và reply; GSDMM chỉ lấy tiếng Việt đủ ngưỡng, modelable, không reply, khử trùng và giới hạn 50 dòng/video mặc định.

comments_audit.parquet chứa ID và lý do giữ/loại; đây là báo cáo riêng, không phải bảng Core. video_decisions.csv ghi bằng chứng metadata. comparison.json ghi toàn bộ tham số, số dòng và kết quả.

GSDMM dùng K=20, alpha=beta=0.1, seed 42, 30 vòng mặc định cho cả hai nhóm. Tắt heuristic dấu tiếng Việt trong train vì Lingua đã lọc ở bước trước. Đầu ra model có thêm cột cluster/text_gsdmm theo chức năng mô hình. topic_examples.json dùng ví dụ ngẫu nhiên có seed, không gọi đó là ví dụ có độ tin cậy cao nhất.

Số dòng sau lọc có thể nhỏ. Các trường hợp không chắc được giữ trong audit, không khẳng định mọi dòng bị loại đều sai chủ đề hoặc sai ngôn ngữ. Các nguồn, bản ghép cũ và curate.py giữ nguyên.
