# Bộ ghép rút gọn: 73.247 bình luận, đúng 18 cột

Lấy ngẫu nhiên không lặp 73.247 dòng từ bản ghép 75.000 dòng, bỏ 1.753 dòng; seed 42. Giữ nguyên mọi giá trị của dòng được giữ, bao gồm ngày đăng/cập nhật/processed_at và nội dung. Không đổi ID hoặc thêm cột.

Thành phần sau lấy mẫu: 48,809 dòng thực tế và 24,438 dòng giả lập theo mẫu. Đây là bộ hỗn hợp, không phải toàn bộ bình luận YouTube thật. Nguồn thật là Core chưa lọc lại độ liên quan video với nhạc AI.

Ngày đăng UTC: 29/08/2026–21/10/2026, đủ 54 ngày. Ngày của phần thật giữ từ nguồn; ngày của phần giả lập là ngày đã được mô phỏng trong bản ghép trước. Không dàn lại ngày khi rút gọn.

comments.parquet và comments.csv đều có 73.247 dòng, đúng 18 cột cùng schema Core. CSV dùng UTF-8 BOM; tokens là chuỗi JSON. preview_100.csv để xem nhanh. summary.json và validation_report.json ghi cách lấy mẫu, nguồn và kiểm tra ngoài bảng.

Các dòng reply có thể không kèm cha do lấy mẫu từng dòng; không sửa quan hệ nguồn để che việc lấy mẫu. Bản 75.000 dòng, hai bộ nguồn và curate.py được giữ nguyên.

Dùng input GSDMM: /project/data/mixed_comments_73247/comments.parquet; chọn thư mục kết quả mới. Số train sẽ giảm sau khi bỏ reply, dòng không modelable, trùng và từ hiếm.
