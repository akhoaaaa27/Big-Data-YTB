# Bộ ghép 73.247 dòng, phiên bản đa dạng cấu trúc

48.809 dòng thực tế giữ nguyên; chỉ viết lại 24.438 dòng giả lập. Đây vẫn là dữ liệu hỗn hợp, không phải toàn bộ bình luận YouTube thật. Nội dung giả lập tiếp tục sinh bằng mẫu và tổ hợp, không phải 24.438 bình luận được viết độc lập hay nhãn được người đánh giá.

Đúng 18 cột Core. Giữ nguyên ID, ngày đăng/cập nhật/processed_at, tác giả, lượt thích và quan hệ thread. Chỉ cập nhật text_raw, text_clean, tokens, n_tokens, is_modelable cho phần giả lập.

Trộn câu ngắn, cảm thán, câu hỏi và ý kiến dài. Kiểm tra mở đầu sau khi bỏ khác biệt chữ hoa, dấu câu, dấu tiếng Việt. Giới hạn mỗi cụm mở đầu 2/3/5 từ hoặc mệnh đề đầu dưới 2,5% của phần giả lập; một từ đầu dưới 4%. Có bình luận ngắn không đủ token cho GSDMM, vẫn giữ cho sentiment và đặt is_modelable theo n_tokens >= 3 đúng quy tắc repo.

comments.parquet/comments.csv đủ 73.247 dòng. synthetic_preview_100.csv xem riêng phần đã sửa; preview_100.csv xem bản ghép. validation_report.json ghi số dòng từng kiểu, tỷ lệ mở đầu lặp, ví dụ và kiểm tra dữ liệu. Cột source đã có giữ nguyên; không thêm cột nhãn/cờ.

Thời gian UTC giữ như bản trước, 29/08/2026–21/10/2026. Phần thật lấy từ Core chưa lọc lại video nhạc AI; không dùng tỷ lệ cảm xúc hay ngày giả lập để kết luận về người xem thật.
