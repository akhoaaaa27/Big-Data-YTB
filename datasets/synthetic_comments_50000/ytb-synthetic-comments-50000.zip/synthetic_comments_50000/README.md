# Dữ liệu GIẢ LẬP: 50.000 bình luận nhạc AI tiếng Việt

Toàn bộ bình luận, video, tác giả, lượt thích và thời gian đều được sinh nhân tạo. Không có ID hay video YouTube thật. Không trộn với dữ liệu thu thập thật.

Thời gian UTC: 01/01/2025–20/10/2026. Có 35.000 positive, 10.000 neutral, 5.000 negative; 20 khía cạnh, mỗi khía cạnh 2.500 dòng. Nhãn được gán từ mẫu sinh, không phải nhãn người đánh giá. Mỗi dòng có một khía cạnh chính; nội dung có thể nhắc thêm khía cạnh khác.

comments.csv: đủ 50.000 dòng, UTF-8 BOM, tokens là chuỗi JSON. preview_100.csv: xem nhanh. comments/: 4 Parquet, mỗi file 12.500 dòng, cùng schema. videos/: 500 video giả lập để nối bảng.

Đủ 18 cột yêu cầu, thêm is_synthetic, synthetic_aspect, synthetic_sentiment. source='synthetic' để không giả danh nguồn api hoặc legacy_csv. parent_id trống cho bình luận gốc; thread_id bằng ID gốc; tổng reply khớp các dòng con. published_at/updated_at/processed_at là UTC. text_clean, tokens và is_modelable dùng đúng ytb.text_clean của repo, giữ emoji cho sentiment.

Dữ liệu theo mẫu, không phải 50.000 bình luận được viết độc lập. Dùng kiểm thử luồng/hiệu năng; không dùng tỷ lệ cảm xúc hay kết quả mô hình trên bộ này làm kết luận về người xem thật.

Train thử từ thư mục repo (chọn đầu ra chưa tồn tại):

```powershell
docker run --rm -v "${PWD}:/project" -w /project -e YTB_DATA_DIR=/project/data gsdmm-local python3 -u -m ytb.modeling.train_topics --input /project/data/synthetic_comments_50000/comments --output-dir /project/data/business/topics/synthetic_seed_42 --seed 42
```

GSDMM mặc định bỏ reply và lọc từ hiếm nên số train có thể dưới 50.000. Cột synthetic_sentiment/synthetic_aspect chỉ phục vụ đối chiếu; không dùng làm đầu vào văn bản.
