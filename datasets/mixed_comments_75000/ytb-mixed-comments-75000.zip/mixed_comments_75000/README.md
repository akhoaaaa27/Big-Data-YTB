# Bộ ghép 75.000 bình luận: 50.000 thật + 25.000 giả lập

Bộ dữ liệu hỗn hợp phục vụ chạy thử. Lấy mẫu không lặp, seed 42; không phải 75.000 bình luận thật độc lập. Dữ liệu thật được lấy từ Core chưa lọc video liên quan AI.

Giữ ngày đăng/cập nhật của dữ liệu thật; chỉ phân bố lại ngày của dữ liệu giả lập. Tổng số dòng mỗi ngày vì vậy không đều.

comments.parquet và comments.csv có đúng 18 cột, cùng thứ tự và kiểu Parquet với Core. Không thêm cột nhãn hoặc cờ. Cột source, ID, văn bản, tokens, lượt thích và quan hệ thread giữ giá trị từ nguồn. processed_at là thời điểm tạo bản ghép, UTC.

Lấy ngẫu nhiên từng dòng nên có thể thiếu bình luận cha trong mẫu. Không đổi parent_id, thread_id hoặc tổng reply nguồn để che việc lấy mẫu.

Nguồn gốc, số dòng và cách xử lý thời gian được ghi trong summary.json, tách khỏi bảng 18 cột. Không sửa hoặc ghi đè hai bộ nguồn và curate.py.
